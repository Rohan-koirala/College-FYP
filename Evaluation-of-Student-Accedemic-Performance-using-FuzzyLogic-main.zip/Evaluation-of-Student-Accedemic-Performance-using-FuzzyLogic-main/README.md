# Evaluation-of-Student-Accedemic-Performance-using-FuzzyLogic
Educational systems typically employ classical methods of performance evaluation.
In this system we have proposed a New Fuzzy Expert System (NFES) for student academic performance evaluation based on Fuzzy Logic techniques. 
It introduces the principles behind fuzzy logic and illustrates how these principles could be applied by educators to evaluating student academic performance. 
In this method, we consider three parameters attendance, internal marks and exteral marks which are used to evaluate students academic performance.
The fuzzy inference system has also been used to obtain Performance of Students for different input values student attendance, marks. 
This system has three modules admin module, student module and faculty module.
For designing this system we are using Python with Django framework, Scikit-Fuzzy tool kit and for front-end we are using HTML5, CSS3, Java script 
and for database we are using SQLite.
