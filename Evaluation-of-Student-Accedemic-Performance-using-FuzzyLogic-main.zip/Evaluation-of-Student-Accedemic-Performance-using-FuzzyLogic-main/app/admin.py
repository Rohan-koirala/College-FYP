from django.contrib import admin
from .models import *
admin.site.register(SchoolDetail)
admin.site.register(SchoolSetting)
admin.site.register(Mark)
admin.site.register(StudentLogin)
admin.site.register(StudentDetail)
admin.site.register(StudentSection)
admin.site.register(StaffDetail)
admin.site.register(Class)
admin.site.register(Section)
admin.site.register(Exam)
admin.site.register(Subject)
admin.site.register(Attendance)